import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AppText, Button, Field, HeroMedia, InlineMessage, Segmented } from '@/components/ui';
import { ApiError } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { imagery } from '@/theme/imagery';
import { colors, space } from '@/theme/tokens';

export default function SignIn() {
  const { signIn, register } = useAuth();
  const [mode, setMode] = useState<'signin' | 'register'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    setError(null);
    if (!email.trim() || !password) return setError('Enter your email and password.');
    if (mode === 'register' && password.length < 10) return setError('Use at least 10 characters for your password.');
    setBusy(true);
    try {
      await (mode === 'signin' ? signIn(email.trim(), password) : register(email.trim(), password));
    } catch (e) {
      const err = e instanceof ApiError ? e : null;
      setError(
        err?.kind === 'network'
          ? "Can't reach FORM. Check your connection and that the API is running."
          : err?.code === 'invalid_request'
            ? 'Check your email address and password.'
            : (err?.message ?? 'Something went wrong. Try again.'),
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.bg }}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
          <HeroMedia image={imagery.onboarding} minHeight={300} style={{ marginBottom: space.sm }}>
            <AppText variant="heading" style={{ letterSpacing: 4, position: 'absolute', top: space.xl, left: space.xl }} accessibilityLabel="FORM">
              FORM
            </AppText>
            <AppText variant="display" header>
              {mode === 'signin' ? 'Welcome back.' : 'Your journey starts here.'}
            </AppText>
            <AppText variant="body" color={colors.textMuted}>
              Train. Eat. Progress.
            </AppText>
          </HeroMedia>

          <Segmented
            options={[
              { value: 'signin', label: 'Sign in' },
              { value: 'register', label: 'Create account' },
            ]}
            value={mode}
            onChange={(m) => {
              setMode(m);
              setError(null);
            }}
          />

          <Field
            label="Email"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            autoComplete="email"
            keyboardType="email-address"
            textContentType="emailAddress"
            placeholder="you@example.com"
          />
          <Field
            label="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
            textContentType={mode === 'signin' ? 'password' : 'newPassword'}
            placeholder={mode === 'register' ? 'At least 10 characters' : '••••••••••'}
            onSubmitEditing={submit}
            hint={mode === 'register' ? 'Your workouts, meals and body data stay private to your account.' : undefined}
          />

          {error ? <InlineMessage tone="danger">{error}</InlineMessage> : null}

          <Button label={mode === 'signin' ? 'Sign in' : 'Create account'} onPress={submit} loading={busy} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, justifyContent: 'center', padding: space.lg, gap: space.lg, width: '100%', maxWidth: 440, alignSelf: 'center' },
});
